워커힐 브랜드 하이어라키 — Netlify 업로드용

배포 방법
  app.netlify.com 로그인 → Sites → "Deploy manually"
  이 netlify-upload 폴더를 통째로 드래그해서 올립니다.
  (폴더 안의 파일만 올리면 안 되고, 폴더째로 올립니다.)

  폴더 대신 netlify-upload.zip 을 드래그해도 됩니다.
  zip 루트에 index.html 이 바로 있도록 압축돼 있습니다.

갱신
  같은 사이트의 Deploys 탭에 폴더를 다시 드래그하면 덮어씁니다.

구성
  index.html     본문 (서체는 Google Fonts에서 불러옵니다)
  logos/         워드마크 (투명 PNG)
  shots/         포장 표기 예시 사진
  _headers       로고 캐시 1년, 검색엔진 색인 차단
  netlify.toml   퍼블리시 경로

참고
  검색 색인은 _headers 와 meta robots 로 막아뒀습니다.
  링크를 아는 사람은 볼 수 있으므로, 비공개가 필요하면
  Netlify 사이트 설정에서 Password protection 을 켜세요.
